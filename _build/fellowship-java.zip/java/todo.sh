#!/usr/bin/env bash

java Todo "$@"
