#!/usr/bin/env bash

ruby todo.rb "$@"
